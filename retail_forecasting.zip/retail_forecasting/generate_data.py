"""Generate a realistic synthetic daily retail sales dataset.

3 stores x 4 products x 3 years (2023-01-01 .. 2025-12-31).
Includes trend, weekly + yearly seasonality, promotions, holidays, noise,
plus a few deliberate data-quality problems (missing values, spikes) to clean.
"""
import numpy as np
import pandas as pd
from retail_utils import calendar_features

rng = np.random.default_rng(42)
dates = pd.date_range("2023-01-01", "2025-12-31", freq="D")
cal = calendar_features(dates)
t_years = (dates - dates[0]).days.values / 365.25

stores = {"Amsterdam": 1.30, "Rotterdam": 1.00, "Utrecht": 0.75}

# base units/day, yearly growth, seasonality function, weekend boost, price (EUR), xmas mult
def s_coffee(doy):   return 1 + 0.08 * np.cos(2 * np.pi * (doy - 15) / 365.25)
def s_icecream(doy): return 1 + 0.70 * np.cos(2 * np.pi * (doy - 200) / 365.25)
def s_jacket(doy):   return 1 + 0.80 * np.cos(2 * np.pi * (doy - 350) / 365.25)
def s_station(doy):  return 0.85 + 1.2 * np.exp(-0.5 * ((doy - 240) / 18) ** 2)

products = {
    "Coffee Beans":    dict(base=60, growth=0.08, season=s_coffee,   weekend=0.10, price=8.5,  xmas=1.25),
    "Ice Cream":       dict(base=45, growth=0.03, season=s_icecream, weekend=0.35, price=4.2,  xmas=0.80),
    "Winter Jacket":   dict(base=12, growth=0.02, season=s_jacket,   weekend=0.25, price=89.0, xmas=1.60),
    "Back-to-School":  dict(base=35, growth=0.04, season=s_station,  weekend=0.05, price=6.5,  xmas=0.70),
}
PROMO_LIFT, PROMO_DISCOUNT = 1.35, 0.15

rows = []
for store, s_mult in stores.items():
    for prod, p in products.items():
        dow_mult = np.where(cal["dow"].values >= 5, 1 + p["weekend"], 1.0)
        mu = (p["base"] * s_mult * (1 + p["growth"]) ** t_years * p["season"](cal["doy"].values)
              * dow_mult * np.where(cal["promo"] == 1, PROMO_LIFT, 1.0)
              * np.where(cal["xmas"] == 1, p["xmas"], 1.0)
              * np.where(cal["newyear"] == 1, 0.6, 1.0))
        mu = mu * rng.lognormal(0, 0.10, len(dates))        # demand noise
        units = rng.poisson(mu).astype(float)
        price = p["price"] * (1.02 ** t_years) * np.where(cal["promo"] == 1, 1 - PROMO_DISCOUNT, 1.0)
        df = pd.DataFrame({"date": dates, "store": store, "product": prod,
                           "units_sold": units, "unit_price": price.round(2),
                           "promo": cal["promo"].values})
        # --- inject data-quality problems ---
        miss = rng.choice(len(df), size=max(3, int(0.004 * len(df))), replace=False)
        df.loc[miss, "units_sold"] = np.nan
        spikes = rng.choice(len(df), size=2, replace=False)
        df.loc[spikes, "units_sold"] = np.round(mu[spikes] * 5)
        rows.append(df)

data = pd.concat(rows, ignore_index=True)
data["revenue"] = (data["units_sold"] * data["unit_price"]).round(2)
data.to_csv("data/sales_data.csv", index=False)
print(data.shape, "| missing units:", int(data.units_sold.isna().sum()))
print(data.head())
